# Pypixel
## _A Simple Python Wrapper for the Minecraft Hypixel API!_


## Features

- Get Player Data and other Info from Hypixel's Servers.
- Get SkyBlock Game Data so you can interact with the SkyBlock API!
- More Coming Very Soon...




## Installation

Pypixel requires [Python](https://python.org/) v3.7+ to run.

Install the package and Get Coding!

```sh
pip3 install pypixelapi
```

[![N|Solid](https://cdn.discordapp.com/attachments/937367051020935222/944701354356641884/Savage_Development-logos_black.png)](https://www.savagedevelopment.tk)

